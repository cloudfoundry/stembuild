function Mock-Automation-Setup {
  echo "mock stemcell automation script executed\n"
}
