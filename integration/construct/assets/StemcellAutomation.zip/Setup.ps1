echo "mock stemcell automation script executed"
Start-Sleep -s 45
Stop-Computer
