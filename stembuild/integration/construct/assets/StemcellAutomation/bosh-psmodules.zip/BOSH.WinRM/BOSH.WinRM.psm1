function Enable-WinRM {
  echo "mock enable WinRM script executed"
}
