echo "mock stemcell automation script executed"
Start-Sleep -s 45
Restart-Computer