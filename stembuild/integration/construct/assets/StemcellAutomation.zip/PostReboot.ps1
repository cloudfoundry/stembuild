echo "mock stemcell automation post-reboot script executed"
Start-Sleep -s 45
Stop-Computer